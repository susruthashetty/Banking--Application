# Banking-Application
 Manage customer accounts and transactions with basic CRUD functionality. • Features are Customer management, deposit/withdraw, balance inquiry, and transaction history. • Built using Spring Boot 3, Spring Data JPA, MySQL.
